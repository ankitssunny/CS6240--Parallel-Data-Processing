package com.neu.cs6240.hw1;

import java.io.IOException;

public class RunAllClasses {

	public static void main(String args[]) throws IOException {
		
		System.out.println("\n\n\nRunning B.1: Sequential Run");
		Solution_B1.main(args);
		System.out.println("\n\n\nRunning B.2: No Locking Run");
		Solution_B2.main(args);
		System.out.println("\n\n\nRunning B.3: Coarse Lock Run");
		Solution_B3.main(args);
		System.out.println("\n\n\nRunning B.4: Fine Lock Run");
		Solution_B4.main(args);
		System.out.println("\n\n\nRunning B.5: No Share Run");
		Solution_B5.main(args);
		System.out.println("\n\n\nRunning C.1: Sequential Run");
		Solution_C1.main(args);
		System.out.println("\n\n\nRunning C.2: No Locking Run");
		Solution_C2.main(args);
		System.out.println("\n\n\nRunning C.3: Coarse Lock Run");
		Solution_C3.main(args);
		System.out.println("\n\n\nRunning C.4: Fine Lock Run");
		Solution_C4.main(args);
		System.out.println("\n\n\nRunning C.5: No Share Run");
		Solution_C5.main(args);
		System.out.println("***End of Program***");
	}
}
