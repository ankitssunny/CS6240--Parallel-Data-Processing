package com.neu.cs6240.hw1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
 * This class is used to read the input file and return a List<String> without making any changes.
 */
public class SourceLoader {

	/*
	 * This method will read the file and return a List<String> which
	 * contains all the lines from the input file.
	 */
	public static List<String> readFile(String filePath) throws IOException {
		
		List<String> str = new ArrayList<String>();
		try {
			// Read the File line by line
			BufferedReader buf = new BufferedReader(new FileReader(filePath));
			String line;
			while ( (line = buf.readLine()) != null) {
				str.add(line);
			}
			buf.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return str;
	}
}
