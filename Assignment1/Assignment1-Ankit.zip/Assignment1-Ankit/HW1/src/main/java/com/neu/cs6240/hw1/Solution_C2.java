package com.neu.cs6240.hw1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Solution_C2Thread implements Runnable {

	private List<String> inputForThread;
	public Map<String, Float[]> totalSumPerStation;


	Solution_C2Thread(List<String> inputForThread, Map<String, Float[]> averageTempByStation) {
		this.inputForThread = inputForThread;
		this.totalSumPerStation = averageTempByStation;
	}

	public void run() {
		/* The Map data structure consists of key,value pairs:
		 * 1. Key: is the station ID
		 * 2. Value: Is an Integer array which consists of only two entries
		 * 			Integer[0] will be the average of this station ID
		 * 			Integer[1] will be the count of total entries found till now for 
		 * 			this station ID.
		 */

		for(String currString: inputForThread) {

			String[] splitCsv = currString.split(",");

			String stationID = splitCsv[0];
			String recordType = splitCsv[2];
			Integer recordValue = Integer.parseInt(splitCsv[3]);

			if (!recordType.equals("TMAX") || recordValue == null )
				continue;

			else {
				// Station ID does not exist. So we create a new entry in Map
				if(!totalSumPerStation.containsKey(stationID)) {
					Float[] value = new Float[2];
					value[0] = (float)recordValue;
					value[1] = (float)1;

					totalSumPerStation.put(stationID, value);
				}

				/* If the station ID already exists we need to recalculate 
				 * the average for this Station ID
				 */
				else {
					Float[] value = totalSumPerStation.get(stationID);
					value[0] += recordValue;
					value[1]++;
					totalSumPerStation.put(stationID, value);
					
					//Running Fibonacci(17) when temperature is added to the running sum
					int f = 0, f1 = 1, f2 = 0;
					for(int i = 1 ; i <= 17; i++) {
						f = f1 + f2;
						f1 = f2;
						f2 = f;
					}
				}
			}
		}
	}
}

public class Solution_C2 {

	public static void main(String[] args) throws IOException {

		// Variables to compute running time
		float averageTime = 0;
		float minimumTime = 0;
		float maximumTime = 0;
		long total = 0;

		List<String> inputString = SourceLoader.readFile(args[0]);
		Map<String, Float[]> totalSumPerStation = new HashMap<String, Float[]>();
		Map<String, Float> averageTempStation = new HashMap<String, Float>();
		
		int sizeOfString = inputString.size();

		/*
		 * Dividing the List<String> equally to be distributed amongst threads
		 */
		List<String> inputThread1 = inputString.subList(0, sizeOfString/4);
		List<String> inputThread2 = inputString.subList(sizeOfString/4, sizeOfString/2);
		List<String> inputThread3 = inputString.subList(sizeOfString/2, (sizeOfString *3)/4);
		List<String> inputThread4 = inputString.subList((sizeOfString *3)/4, sizeOfString);


		// Running the program 10 times within the same execution
		for (int i = 1 ; i <= 10 ; i++) {
			System.out.println("Loop: " +i);
			/*
			 * Creating a Thread for each logical core. I have an i5 which supports 
			 * hyperthreading hence 4 threads.
			 */
			Thread thread1 = new Thread(new Solution_C2Thread(inputThread1, totalSumPerStation));
			Thread thread2 = new Thread(new Solution_C2Thread(inputThread2, totalSumPerStation));
			Thread thread3 = new Thread(new Solution_C2Thread(inputThread3, totalSumPerStation));
			Thread thread4 = new Thread(new Solution_C2Thread(inputThread4, totalSumPerStation));

			// Starting the threads
			long startTime = System.currentTimeMillis();
			thread1.start();
			thread2.start();
			thread3.start();
			thread4.start();

			// Waiting till all the threads have completed their jobs.
			try {
				thread1.join();
				thread2.join();
				thread3.join();
				thread4.join();

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			for(String stationID: totalSumPerStation.keySet()) {
				float value = totalSumPerStation.get(stationID)[0]/ totalSumPerStation.get(stationID)[1];
				averageTempStation.put(stationID, value);
			}

			// Computing end time here
			long endTime = System.currentTimeMillis();
			long currTime = endTime - startTime;
			total += currTime;
			
			if (i == 1) {
				maximumTime = currTime;
				minimumTime = currTime;
			}
			else {
				// calculating maximum Time
				if (currTime > maximumTime)
					maximumTime = currTime;
				// calculating minimum Time
				if (currTime < minimumTime)
					minimumTime = currTime;
			}
			
			if (i == 10) {
				File dir= new File("output");
				if(!dir.exists())	
					new File("output").mkdir();
				File file = new File("output/Solution_C2.csv");
				FileWriter fw = new FileWriter(file.getAbsoluteFile());
				BufferedWriter buf = new BufferedWriter(fw);

				for( String stationID: averageTempStation.keySet() ) {
					String str = stationID + "," + averageTempStation.get(stationID) + "\n";
					buf.write(str);
				}
				buf.close();
			}
			// Clearing out the map for the next run.
			averageTempStation.clear();
			totalSumPerStation.clear();
		}
		// calculating average running time
		averageTime = total / 10;
		System.out.println("Minimum Running Time: " +minimumTime);
		System.out.println("Maximum Running Time: " +maximumTime);
		System.out.println("Average Running Time: " +averageTime);
	}
}