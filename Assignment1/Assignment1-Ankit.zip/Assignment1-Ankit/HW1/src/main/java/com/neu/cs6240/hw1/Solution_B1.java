package com.neu.cs6240.hw1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Solution_B1 {

	/*
	 * Class constructor which loads the List<String> by calling the SourceLoader class
	 */
	Solution_B1(String filePath) throws IOException {

		InputString = SourceLoader.readFile(filePath);
	}

	private List<String> InputString;
	private Map<String, Float[]> totalSumPerStation = new HashMap<String, Float[]>();
	private Map<String, Float> averageTempStation = new HashMap<String, Float>();
	

	/*
	 * Read the entire List<String> and compute the average temperature per station
	 * only for TMAX values
	 * StationID, Date, RecordType, RecordValue, ObersvationTme
	 * MOE00147755,19120101,PRCP,0,,,E,
	 * USC00365915,19120101,TMAX,22,,,6,
	 */
	private void calculateAverageTemperature() {

		/* The Map data structure consists of key,value pairs:
		 * 1. Key: is the station ID
		 * 2. Value: Is an Integer array which consists of only two entires
		 * 			Integer[0] will be the average of this station ID
		 * 			Integer[1] will be the count of total entries found till now for 
		 * 			this station ID.
		 */

		for(String currString: InputString) {

			String[] splitCsv = currString.split(",");

			String stationID = splitCsv[0];
			String recordType = splitCsv[2];
			Integer recordValue = Integer.parseInt(splitCsv[3]);

			if (!recordType.equals("TMAX") || recordValue == null )
				continue;

			else {
				// Station ID does not exist. So we create a new entry in Map
				if(!totalSumPerStation.containsKey(stationID)) {
					Float[] value = new Float[2];
					value[0] = (float)recordValue;
					value[1] = (float)1;

					totalSumPerStation.put(stationID, value);
				}

				/* If the station ID already exists we need to recalculate 
				 * the average for this Station ID
				 */
				else {
					Float[] value = totalSumPerStation.get(stationID);
					value[0] += recordValue;
					value[1]++;
					totalSumPerStation.put(stationID, value);
				}
			}
		}
		
		for(String stationID: totalSumPerStation.keySet()) {
			float value = totalSumPerStation.get(stationID)[0]/ totalSumPerStation.get(stationID)[1];
			averageTempStation.put(stationID, value);
		}
	}

	public static void main(String[] args) throws IOException {
		// Variables to compute Running Time
		float averageTime = 0;
		float minimumTime = 0;
		float maximumTime = 0;
		long total = 0;
		
		Solution_B1 b1 = new Solution_B1(args[0]);

		// Running the program 10 times within the same execution
		for( int i = 1; i <= 10; i++ ) {
			System.out.println("Loop: " +i);
			long startTime = System.currentTimeMillis();
			b1.calculateAverageTemperature();
			long endTime = System.currentTimeMillis();

			// calculating time for this run
			long currTime = endTime - startTime;
			total += currTime;
			if (i == 1) {
				maximumTime = currTime;
				minimumTime = currTime;
			}
			else {
				// calculating maximum Time
				if (currTime > maximumTime)
					maximumTime = currTime;
				// calculating minimum Time
				if (currTime < minimumTime)
					minimumTime = currTime;
			}
			// Now writing the Map data structure in a csv file for comparison with other program's o/p. 

			if (i == 10) {
				File dir= new File("output");
				if(!dir.exists())	
					new File("output").mkdir();
				File file = new File("output/Solution_B1.csv");
				FileWriter fw = new FileWriter(file.getAbsoluteFile());
				BufferedWriter buf = new BufferedWriter(fw);

				for( String stationID: b1.averageTempStation.keySet() ) {
					String str = stationID + "," + b1.averageTempStation.get(stationID) + "\n";
					buf.write(str);
				}
				buf.close();
			}
			// Clearing out the map for the next run.
			b1.averageTempStation.clear();
			b1.totalSumPerStation.clear();

		}
		// calculating average running time
		averageTime = total / 10;
		System.out.println("Minimum Running Time: " +minimumTime);
		System.out.println("Maximum Running Time: " +maximumTime);
		System.out.println("Average Running Time: " +averageTime);
	}
}